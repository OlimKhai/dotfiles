sudo
pwd
ls
cd Desctop
cd Desktop
touch [1..3].txt 
pwd
ls
rm [1..3].txt
ls
cls
clear
cls
clls
mc
dir
rm -rf doc
dir
ls
clear
ls 
quit
exit
bash 
bash
ls
javac Start.java
javac
wich java
java Start.java
vim
ls
mkdir java
ls
rm -rf java
ls
dnf copr enable maximbaz/browserpass
dnf install browserpass
emerge www-plugins/browserpass
sudo dnf copr enable maximbaz/browserpass
sudo dnf install browserpass
pass insert [OPTIONAL DIR]/[FILENAME]
pass [OPTIONAL DIR]/[FILENAME]
pass [--echo,-e | --multiline,-m] [--force,-f]
[--echo,-e | --multiline,-m] [--force,-f]/[FILENAME]
pass [OPTIONAL DIR]/[FILENAME]
pass generate --in-place FILENAME
pass [OPTIONAL DIR]/[FILENAME]
pass insert email/gmail.com
gpg --list-secret-list
gpg --list-secret-keys
gpg --full-generate-key
gpg --list-secret-keys
pass init 1032242468@rudn.ru
pass insert github.com
pass email/gmail.com
pass github.com
pass insert email/gmail.com
pass
pass generate --in-place FILENAME
pass generate --in-place github.com
chezmoi init https://github.com/<username>/dotfiles.git
chezmoi init https://github.com/OlimKhai/dotfiles.git
chezmoi diff
chezmoi apply -v
chezmoi init --apply https://github.com/OlimKhai/dotfiles.git
chezmoi update
git pull --autostash --rebase
chezmoi git pull -- --autostash --rebase
chezmoi apply
chezmoi git pull -- --autostash --rebase && chezmoi diff
chezmoi apply
nano ~/.config/chezmoi/chezmoi.toml
chezmoi add ~/.bashrc
sudo dnf -y install dunst fontawesome-fonts powerline-fonts light /
sudo dnf -y install dunst fontawesome-fonts powerline-fonts light fuzzel swaylock kitty waybar swaybg wl-clipboard mpv grim slurp
sudo dnf copr enable peterwu/iosevka
sudo dnf search iosevka
sudo dnf install iosevka-fonts iosevka-aile-fonts iosevka-curly-fonts iosevka-slab-fonts iosevka-etoile-fonts iosevka-term-fonts
sh -c "$(wget -qO- chezmoi.io/get)"
gh repo create dotfiles --template="yamadharma/dotfiles-template" --private
chezmoi init git@github.com:OlimKhai/dotfiles.git
chezmoi init https://github.com/OlimKhai/dotfiles.git
sudo dnf install gh
gh auth login
gh repo create dotfiles --private
gh repo create dotfiles --template="yamadharma/dotfiles-template" --private
gh repo delete OlimKhai/dotfiles --confirm
gh auth refresh -h github.com -s delete_repo
gh repo delete OlimKhai/dotfiles
gh repo create dotfiles --template="yamadharma/dotfiles-template" --private
chezmoi init git@github.com:<OlimKhai>/dotfiles.git
chezmoi init git@github.com:OlimKhai/dotfiles.git
chezmoi diff
chezmoi apply -v
chezmoi init --apply https://github.com/<username>/dotfiles.git
chezmoi init --apply https://github.com/OlimKhai/dotfiles.git
nano lab-report.md
sudo dnf install pandoc
pandoc lab5-report.md -o lab5-report.html
pandoc lab5-report.md -o lab5-report.pdf
sudo dnf install pdflatex
pandoc lab5-report.md -o lab5-report.pdf
pandoc lab5-report.md -o lab5-report.pdf --pdf-engine=pdfLatex
sudo dnf install wkhtmltopdf
pandoc lab5-report.md -o lab5-report.pdf
pandoc lab5-report.md -o lab5-report.pdf --pdf-engine=pdflatex
pandoc lab5-report.md -o lab5-report.docx
ls -lh lab5-report.*
firefox lab5-report.html
cat lab5-report.md
nano lab5-report.md
firefox lab5-report.html
nano lab5-report.md
pandoc lab05-report.md -o lab05-report.docx
pandoc lab05-report.md -o lab05-report.html
firefox lab05-report.html
cd ~
mkdir newdir
ls
mkdir ~/newdir/morefun
mkdir letters memos misk
ls
rmdir letters memos misk
ls
rm ~/newdir
rm -r ~/newdir
ls
ls ~/newdir
man ls
ls -lt
/tmp
man cd
man mkdir
man rm
history
cd Desktop
set -o | grep history
cd Desktop
ls
ls -la
man pwd
cd ~
ls -l
ls -R
history
ls -aIF
nano lab6-report.md
pandoc lab6-report.md -o lab6-report.html
pandoc lab6-report.md -o lab6-report.pdf
sudo dnf install pandoc wkjtmltopdf
sudo dnf install pandoc wkhtmltopdf
pandoc lab6-report.md -o lab6-report.pdf
dnf install pandoc 
sudo dnf install pandoc
pandoc lab6-report.md -o lab6-report.pdf
pandoc lab6-report.md -o lab6-report.docx
firefox lab6-report.html
cat lab6-report.md
nano lab6-report.md
pandoc lab6-report.md -o lab6-report.docx
pandoc lab6-report.md -o lab6-report.html
pandoc lab6-report.md -o lab6-report.html
man rmdir
pandoc la
cd
pandoc lab6-report.md -o lab6-report.html
pandoc ~/home/Desktop/lab6/lab6-report.md -o lab6-report.html
pandoc lab06-report.md -o lab06-report.html
cd ~/Desktop
cd ~/Desktop/lab6
ls -la *.md
pandoc lab06-report.md -o lab06-report.html
pandoc lab06-report.md -o lab06-report.pdf
pandoc lab06-report.md -o lab06-report.docx
firefox lab06-report.html
cd ~/Desktop
git init
git add lab6
git commit -m
git commit -m "All lab reports"
git remote add origin git@github.com:OlimKhai/dotfiles.git
git branch -M main
git push -u  origin main
git push
git tag -a v1.0 -m "Lab 6 completed"
git push origin v1.0
git add lab06-report.md lab06-report.html lab06-report.docx lab06-report.html.pdf
git add lab06-report.html lab06-report.docx lab06-report.html.pdf
cd ~/Desktop/lab6
git add lab06-report.html lab06-report.docx lab06-report.html.pdf
git add lab06-report.md lab06-report.html lab06-report.docx lab06-report.html.pdf
git status
git commit -m "All lab06 reports"
git push
git tag -a v1.0 -m "Lab 06 completed"
pwd
cd /tmp
cd
/tmp
cd
cd /tmp
pwd
ls
ls -a
ls -l
ls -F
ls -aIF
ls /var/spool
ls -d /var/spool/cron
cd ~
ls -1
l
cd ~/Desktop/lab5
cd ~/Desktop/lab05
cd ~/Desktop/lab5
cd
cd ~/Desktop/lab5
cd ~/home/Desktop/lab5
cd ~/Desktop/lab5/
cd ~/Desktop/Lab5
git remote add origin https://github.com/OlimKhai/dotfiles.git
git add .
git tag -a v1.0-lab05 -m "Laboratory work 5: The Fundamentals of the Unix command-line user interface"
gitt push origin v1.0-lab05
git push origin v1.0-lab05
св
cd
ls /usr/include/sys/io.h
ls /usr/include/sys/
cd ~/Desktop/
ls /usr/include/sys/
ls /usr/include/sys
sudo dnf install glibc-headers kernel-headers
ls /usr/include/sys/
ls /usr/include/sys/io.h
cp /usr/include/sys/io.h ~/equipment
mkdir ~/ski.places
ls -ld ~/ski.places
mv ~/equipment ~/ski.places
ls ~/ski.places
mv ~/ski.places/equipment ~/ski.places/equiplist
ls  ~/ski.places/equiplist
ls ~/ski.places
touch ~/abc1
cp ~/abc1 ~/ski.places/equiplist2
ls ~/ski.places/
mkdir ~/ski.places/equipment
ls -l ~/ski.places
mv ~/ski.places/equiplist ~/ski.places/equipment
mv ~/ski.places/equiplist2  ~/ski.places/equipment
ls ~/ski.places/equipment
mkdir ~/newdir
mv ~/newdir ~/ski.places/plans
ls -l ~/ski.places/
cd
mkdir australia play
touch my_os feathers
chmod 000 australia play my_os feathers
chmod 744 australia
chmod 711 play
chmod 544 my_os
chmod 664 feathers
ls -l australia play my_os feathers
less /etc/passwd
cat  /etc/passwd
cp ~/feathers ~/file.old
mv ~/file.old ~/play/
cp -r ~/play ~/fun
mv ~/fun ~/play/games
ls ~/play
chmod u-r ~/feathers
ls -l ~/feathers
cat ~/feathers
cp ~/feathers ~/feathers.copy
chmod u+r ~/feathers
ls -l ~/feathers
chmod u-x ~/play
ls -ld ~/play
cd ~/play
chmod u+x ~/play
cd ~/play
pwd
cd
man mount
man kill
gh auth login
gh release create v1.0 --title "Lab 07 Completed" --notes "Добавлены все файлы лабораторной работы 7"
cd ~/dotfiles
git tag -a v1.0 -m "Release version 1.0"
git tag -a v2.0 -m "Release version 2.0"
git push origin v2.0
git tag -a v2.0-lab07 -m "Release version 2.0"
git push origin v2.0-lab07
man fsck
man mkfs
mkdir -p ~/lab06/reports/screenshots
cd ~/lab06/reports
touch lab06-report.md
nano lab06-report.md
pandoc lab07-report.md -o lab07-report.html
pandoc lab07-report.md -o lab07-report.pdf
pandoc lab07-report.md -o lab07-report.docx
cd ~/lab06/
git add .
git init
cd ~/lab07
git init
git remote add origin https://github.com/OlimKhai/dotfiles
git add . 
git commit -m "Initial commit for lab07"
git push -u origin main
cd ~
cp -r ~/lab07 ~/dotfiles/lab07
git clone https://github.com/OlimKhai/dotfiles.git
cd dotfiles
cp -r ~/lab07 ~/dotfiles/lab07
git add lab07
git commit -m "Add lab07 folder"
git push origin master
cp -r ~/lab07/* ~/dotfiles/lab07/
cd ~
cp -r ~/lab07/* ~/dotfiles/lab07/
git add lab07
cd ~/dotfiles
git add lab07/
git commit -m "Add all lab07 files"
git push origin master
sudo cp -r ~/lab07/* ~/dotfiles/lab07
git add lab07/
git commit -m "Add lab07 files"
cd ~
sudo cp -r ~/lab07/* ~/dotfiles/lab07
cd ~/dotfiles
git add lab07/
git commit -m "Add all lab07 files"
cd ~
chmod -R 755 ~/lab07
cp -r ~/lab07/* ~/dotfiles/lab07
cp ~/lab07
cd ~/lab07
find . -maxdepth 1 -type f -exec cp {} ~/dotfiles/lab07/ \;
cd ~/dotfiles
ls -la lab07/
sudo cp -a ~/lab07.1
sudo cp -a ~/lab07
sudo cp -a ~/lab07 .
sudo chown _R $USER:$USER lab07
sudo chown -R $USER:$USER lab07
git add lab07/
git status
git push origin master
git submodule deinit -f lab07
git rm -f lab07
rm -rf .git/modules/lab07
git add lab07/
git status
git add .
git push origin main
git push origin master
cd ~
git tag -a v1.0-lab07 -m "Laboratory work 7: Commands for catalog and command interaction"
cd ~
login
password
nano lab8-report.md
pandoc lab8-report.md -o lab8-report.html
nano lab8-report.md
pandoc lab8-report.md -o lab8-report.html
pandoc lab8-report.md -o lab8-report.docx
pandoc lab8-report.md -o lab8-report.pdf
cd ~/Documents

nano lab8-report.md

pandoc lab8-report.md -o lab8-report.docx
pandoc lab8-report.md -o lab8-report.html
open firefox
sudo apt update
sudo apt install git -y
sudo dnf update
sudo dnf install git -y
sudo dnf update
vi hello.sh
cd ~
mkdir -p ~/backup
SCRIPT_NAME=$(basename "$0")
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
tar -czf ~/backup/${SCRIPT_NAME}.${TIMESTAMP}.tar.gz "$0"
echo "Backup created: ~/backup/${SCRIPT_NAME}.${TIMESTAMP}.tar.gz"
echo "Total arguments: $#"
echo "All arguments:"
echo ""
echo "Using array access"
for ((i=1; i<=$#; i++))
do
for ((i=1; i<=$#; i++))
do echo "Arg $i: ${!i}"; done
if [ -z "$1" ]; then DIR="."; else DIR="$1"; fi
if [ ! -d "$DIR" ]; then echo "Error: $DIR is not a directory"; exit 1; fi
echo "Contents of $DIR:"
echo ""
fpr file in "$DIR"/*
for file in "$DIR"/*; do if [ -f "$file" ]; then TYPE="file"; elif [ -d "$file" ]; then TYPE="directory"; elif [ -L "$file" ]; then TYPE="symlink"; else TYPE="unknown"; fi;  PERMISSIONS=""; [ -r "$file" ] && PERMISSIONS="${PERMISSIONS}read "; [ -w "$file" ] && PERMISSIONS="${PERMISSIONS}write "; [ -x "$file" ] && PERMISSIONS="${PERMISSIONS}execute ";  SIZE=$(stat -c%s "$file" 2>/dev/null || echo "0");  echo "$(basename "$file"): $TYPE, size: $SIZE bytes, permissions: $PERMISSIONS"; done
if [ $# -lt 2 ]; then echo "Usage: $0 <extension> <directory>"; echo "Example: $0 .txt /home/user/documents"; exit 1; fi
EXTENSION="$1"
DIRECTORY="$2"
if [ ! -d "$DIRECTORY" ]; then echo "Error: Directory $DIRECTORY does not exist"; exit 1; fi
cd ~/projects/lab12
pandoc os-intro--lab12--report.md -o os -intro--lab12--report.docx
pandoc os-intro--lab12--report.md -o os-intro--lab12--report.docx
sudo dnf install wkhtmltopdf
sudo dnf install python3-weasyprint
pandoc os-intro--lab12--report.md -o os-intro--lab12--report.html --toc --standalone
pandoc os-intro--lab12--report.md -o os-intro--lab12--report.html --toc --standalone --mathjax
pandoc os-intro--lab12--report.md -o os-intro--lab12--report.docx --toc
wkhtmltopdf os-intro--lab12--report.html os-intro--lab12--report.pdf
nano os-intro--lab12--presentation.md
[200~pandoc os-intro--lab12--report.md -o os-intro--lab12--report.html --toc --standalone --mathjax
pandoc os-intro--lab12--report.md -o os-intro--lab12--report.html --toc --standalone --mathjax
weasyprint os-intro--lab12--report.html os-intro--lab12--report.pdf
pandoc os-intro--lab12--presentation.md -o os-intro--lab12--presentation.html --toc --standalone --mathjax
weasyprint os-intro--lab12--presentation.html os-intro--lab12--presentation.pdf
pandoc os-intro--lab12--presentation.md -o os-intro--lab12--presentation.docx
cd ~/projects
git clone https://github.com/OlimKhai/dotfiles.git
cd dotfiles
cp -r ~/projects/lab12
cp -r ~/projects/lab12 .
rm -rf lab12/.git
git add lab12/
git commit -m "Add all lab12 files (scripts, report, presentation, screenshots)"
git push origin main
sudo dnf install git-lfs
git push origin master
git branch -M master main
git push origin main
git remote add gitverse https://gitverse.ru/OlimKhai/dotfiles1.git
git push gitverse master
cd ~/projects
git push gitverse master
cd ~/projects/dotfiles
git pull origin main --rebase
git push gitverse main
git remote v-v
git remote -v
git push gitverse main
git pull gotverse main --rebase
git merge --abort
git pull gitverse main --rebase
git rebase --abort
git status
git pull gitverse main --rebase
git rebase --skip
git rebase --continue
git status
nano missfont.log
git checkout --theirs missfont.log
git checkout --ours missfont.log
git add missfont.log
git rebase --continue
git rebase --abort
git push gitverse main --force-with-lease
cd lab12
cd ~/projects/lab12
git push gitverse main --force-with-lease
nano task1_search.sh
chmod +x task1_search.sh
echo -e "apple\nApple\nBANANA\nbanana" > input.txt
./task1_search.sh -i input.txt -o result.txt -p "apple" -n
cat result.txt
